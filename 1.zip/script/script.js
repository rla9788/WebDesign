$('.main > li').mouseover(function(){
    $(this).children('.submenu').stop().slideDown(200);
});
$('.main > li').mouseout(function(){
    $(this).children('.submenu').stop().slideUp(200);
});

setInterval(function(){
    $('.slidelist').delay(2000);
    $('.slidelist').animate({marginLeft: -1000});
    $('.slidelist').delay(2000);
    $('.slidelist').animate({marginLeft: -2000});
    $('.slidelist').delay(2000);
    $('.slidelist').animate({marginLeft: 0});

});